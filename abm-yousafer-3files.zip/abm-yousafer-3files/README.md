# ABM YouSafer

Arquivos para GitHub Pages:

- index.html
- styles.css
- script.js

Como publicar:

1. Suba os tres arquivos na raiz do repositorio.
2. Va em Settings > Pages.
3. Source: Deploy from a branch.
4. Branch: main.
5. Folder: /root.
6. Acesse: https://viniciusagnes.github.io/ABMYouSafer/
