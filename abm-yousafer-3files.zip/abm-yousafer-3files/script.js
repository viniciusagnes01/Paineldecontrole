(function () {
  const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 });

  const navToggle = document.querySelector('[data-nav-toggle]');
  const navLinks = document.querySelector('[data-nav-links]');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => navLinks.classList.toggle('open'));
    navLinks.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => navLinks.classList.remove('open'));
    });
  }

  const form = document.querySelector('[data-churn-form]');
  if (form) {
    const base = form.querySelector('[data-base]');
    const arpu = form.querySelector('[data-arpu]');
    const churn = form.querySelector('[data-churn]');
    const reduction = form.querySelector('[data-reduction]');
    const loss = document.querySelector('[data-loss]');
    const saved = document.querySelector('[data-saved]');

    const updateCalc = () => {
      const baseValue = Number(base.value || 0);
      const arpuValue = Number(arpu.value || 0);
      const churnValue = Number(churn.value || 0) / 100;
      const reductionValue = Number(reduction.value || 0) / 100;
      const monthlyLoss = baseValue * churnValue * arpuValue;
      const preserved = monthlyLoss * reductionValue;
      loss.textContent = money.format(monthlyLoss);
      saved.textContent = money.format(preserved);
    };

    form.querySelectorAll('input').forEach((input) => input.addEventListener('input', updateCalc));
    updateCalc();
  }

  const tabs = document.querySelector('[data-tabs]');
  if (tabs) {
    const buttons = tabs.querySelectorAll('[data-tab]');
    const panels = tabs.querySelectorAll('[data-panel]');
    buttons.forEach((button) => {
      button.addEventListener('click', () => {
        const target = button.getAttribute('data-tab');
        buttons.forEach((item) => item.classList.remove('active'));
        panels.forEach((panel) => panel.classList.remove('active'));
        button.classList.add('active');
        const nextPanel = tabs.querySelector(`[data-panel="${target}"]`);
        if (nextPanel) nextPanel.classList.add('active');
      });
    });
  }

  const filterButtons = document.querySelectorAll('[data-week-filter]');
  const contentCards = document.querySelectorAll('[data-week]');
  filterButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const filter = button.getAttribute('data-week-filter');
      filterButtons.forEach((item) => item.classList.remove('active'));
      button.classList.add('active');
      contentCards.forEach((card) => {
        const week = card.getAttribute('data-week');
        card.classList.toggle('hidden', filter !== 'all' && week !== filter);
      });
    });
  });

  const revealElements = document.querySelectorAll('.card, .framework-card, .tier, .content-card, .timeline article, .action-plan article, .calc');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.animate([
          { opacity: 0, transform: 'translateY(16px)' },
          { opacity: 1, transform: 'translateY(0)' }
        ], { duration: 520, easing: 'ease-out', fill: 'forwards' });
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  revealElements.forEach((element) => {
    element.style.opacity = '0';
    observer.observe(element);
  });
})();
