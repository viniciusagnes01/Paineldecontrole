const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const required = [
  'index.html',
  'src/styles.css',
  'src/app.js',
  'src/data/seed.js',
  'src/services/integrations.js',
  'src/assets/v4-company-logo.jpg'
];

for (const file of required) {
  const full = path.join(root, file);
  if (!fs.existsSync(full)) throw new Error(`Arquivo obrigatório ausente: ${file}`);
}

const css = fs.readFileSync(path.join(root, 'src/styles.css'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const app = fs.readFileSync(path.join(root, 'src/app.js'), 'utf8');

const checks = [
  ['viewport responsivo', html.includes('width=device-width, initial-scale=1.0')],
  ['grid seguro main', css.includes('grid-template-columns: var(--sidebar) minmax(0, 1fr)')],
  ['main sem overflow horizontal', css.includes('overflow-x: hidden')],
  ['breakpoint tablet', css.includes('@media (max-width: 1040px)')],
  ['breakpoint mobile', css.includes('@media (max-width: 680px)')],
  ['aba concorrentes', app.includes('Concorrentes SEMrush')],
  ['config cliente', app.includes('Configuração do Cliente')],
  ['CRUD local', app.includes('localStorage')]
];

for (const [label, ok] of checks) {
  if (!ok) throw new Error(`Falha no checklist: ${label}`);
}

console.log('Layout check OK: arquivos, responsividade e CRUD local presentes.');
