# Integração dinâmica de mídia - Google Sheets

Cliente implementado: ST1 Internet

Planilha: `ST1 Internet | GrowthPack V26 (Inside Sales)`

Fontes principais:

- `1.0 Mensal` para gestão mensal consolidada.
- `2.0 Semanal` para acompanhamento semanal e pacing.

Fontes secundárias preparadas:

- `bd Meta Ads` para drill-down por campanha/conjunto/anúncio.
- `bd Google Ads ` para drill-down por campanha/palavra-chave.

## Onde aparece

Entre em `ST1 Internet > Mídia & Ads` e clique em `Sincronizar mídia agora`.

O sistema gera:

- Investimento mensal.
- Investimento semanal.
- Pacing.
- Impressões.
- Cliques.
- Leads de mídia.
- CPL.
- CPC.
- CTR.
- Conversão clique -> lead.
- Histórico mensal.
- Histórico semanal.
- Cruzamento com origem Meta/Google do CRM.

## Por que usar mensal/semanal primeiro

As abas `1.0 Mensal` e `2.0 Semanal` são mais seguras para dashboard executivo porque já estão consolidadas e reduzem risco de variação de colunas nas bases brutas. As abas `bd Meta Ads` e `bd Google Ads` devem entrar depois para auditoria e detalhamento.

## Configuração

Em `ST1 Internet > Config do Cliente`, preencha:

- `Mídia Sheets • Spreadsheet ID`
- `Mídia Sheets • Aba mensal`
- `Mídia Sheets • Aba semanal`
- `Mídia Sheets • GID mensal`
- `Mídia Sheets • GID semanal`
- `Mídia Sheets • Proxy N8N opcional`

## Produção com N8N

Fluxo recomendado:

1. Webhook GET `/performance/st1-internet`
2. Google Sheets: ler `1.0 Mensal` e `2.0 Semanal`
3. Code: normalizar labels e retornar CSV/JSON
4. Respond to Webhook: devolver payload ao front-end
