# Checklist de responsividade

- Desktop: sidebar fixa com 330px e conteúdo em `minmax(0, 1fr)`.
- Tablet: sidebar vira bloco superior, cartões reduzem para 2 ou 3 colunas.
- Mobile: todos os grids viram 1 coluna e as tabelas têm scroll horizontal próprio.
- Nenhuma página depende de largura fixa.
- Tabelas longas usam `.table-wrap` para evitar quebrar a viewport.
- Abas por cliente usam scroll horizontal quando necessário.
