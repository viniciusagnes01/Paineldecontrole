# Integração dinâmica CRM - Google Sheets

Cliente implementado: ST1 Internet

Planilha: `ST1 Internet | GrowthPack V26 (Inside Sales)`

Aba de origem: `BASE_CRM`

GID: `1699545222`

## Colunas esperadas

A aplicação lê a aba `BASE_CRM` e identifica as seguintes colunas:

- Data
- Lead ID
- Nome
- Valor
- LEAD
- MQL
- SQL
- OPORTUNIDADE
- COMPRA
- LEAD PERDIDO
- META ADS
- GOOGLE ADS
- RESPONSAVEL
- MOTIVO DE PERDA

## Onde aparece no sistema

Entre no cliente `ST1 Internet` e abra a aba `CRM & Funil`.

O botão `Sincronizar CRM agora` tenta buscar a planilha, transformar as linhas em JSON e atualizar o funil do cliente.

## Como deixar dinâmico no Netlify

Existem duas opções.

### Opção 1 - Google Sheets público

Use quando a planilha puder ficar com acesso `Qualquer pessoa com o link pode visualizar`.

O front-end usa a URL CSV do Google:

```txt
https://docs.google.com/spreadsheets/d/<SPREADSHEET_ID>/gviz/tq?tqx=out:csv&sheet=BASE_CRM
```

### Opção 2 - N8N como proxy, recomendada

Use quando a planilha for privada ou quando você quiser padronizar segurança.

Fluxo sugerido:

1. Trigger: Webhook GET `/crm/st1-internet`
2. Node Google Sheets: ler aba `BASE_CRM`
3. Node Code: normalizar colunas e retornar CSV ou JSON
4. Respond to Webhook: devolver dados para o front-end

No sistema, entre em `ST1 Internet > Config do Cliente` e preencha `CRM Sheets • Proxy N8N opcional` com a URL do webhook.

## Arquivos alterados

- `src/services/sheets-crm.js`: busca CSV, parseia e agrega dados.
- `src/app.js`: renderização dinâmica da aba `CRM & Funil` e botão de sincronização.
- `src/data/seed.js`: configuração da fonte CRM da ST1 Internet.
- `index.html`: carrega o serviço `sheets-crm.js`.

## O que é calculado automaticamente

- Leads
- MQL
- SQL
- Oportunidades
- Compras/vendas
- Leads perdidos
- Valor total
- Ticket médio
- Taxas de conversão do funil
- Motivos de perda
- Performance por responsável
- Origem Meta Ads / Google Ads / Orgânico
- Evolução mensal
- Últimos leads importados


## Relatório de perdas completo

A versão v6 adiciona um bloco completo de perdas dentro de `CRM & Funil`, incluindo ranking de motivos, responsáveis, origem, matriz responsável x motivo, últimos leads perdidos e plano de recuperação.
