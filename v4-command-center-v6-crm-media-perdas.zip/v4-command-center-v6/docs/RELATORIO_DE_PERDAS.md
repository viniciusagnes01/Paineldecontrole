# Relatório de perdas - CRM

A aba `CRM & Funil` contém um relatório de perdas completo para a ST1 Internet.

## Fonte

A fonte é a aba `BASE_CRM`.

Colunas usadas:

- `LEAD`
- `MQL`
- `SQL`
- `OPORTUNIDADE`
- `COMPRA`
- `LEAD PERDIDO`
- `META ADS`
- `GOOGLE ADS`
- `RESPONSAVEL`
- `MOTIVO DE PERDA`

## O que o relatório mostra

- Total de leads perdidos.
- Taxa de perda sobre o funil.
- Maior motivo de perda.
- Responsável com maior volume de perda.
- Taxa de venda.
- Ranking de motivos de perda.
- Perdas por origem: Meta Ads, Google Ads e orgânico/outros.
- Performance por responsável.
- Matriz responsável x motivo.
- Últimos leads perdidos.
- Plano imediato de recuperação.

## Uso operacional

O relatório foi desenhado para apoiar check-ins, diagnóstico comercial e priorização de ações. O gestor deve olhar primeiro o maior motivo de perda, depois o responsável crítico e por fim cruzar a origem de mídia com o motivo de perda.
