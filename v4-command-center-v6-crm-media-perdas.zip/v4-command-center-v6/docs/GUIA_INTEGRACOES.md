# Guia de Integrações - V4 Command Center

## Camada recomendada

Front-end estático -> N8N/API interna -> fontes externas -> banco ou JSON tratado.

## Fontes previstas

- Meta Ads: investimento, leads, CPL, CTR, frequência, campanha, criativo e evento.
- Google Ads: investimento, leads, CPL, palavras-chave, conversões e valor de conversão.
- LinkedIn Ads: investimento, leads B2B, CPL e campanhas.
- CRM Moskit/Kommo: lead, MQL, SQL, oportunidade, venda, ticket e motivo de perda.
- Evolution API: ID do grupo, mensagens, status e alertas operacionais.
- SEMrush: concorrentes, domínio, tráfego, keywords, autoridade, palavras pagas e gaps.
- eKyte: título da task, status, executor, tipo, prioridade, início, entrega e progresso.
- Google Drive/Sheets: histórico, planilhas semanais, check-ins e dados auxiliares.

## Onde plugar

O arquivo `src/services/integrations.js` já lista os endpoints que devem ser implementados em backend/N8N.

## Segurança

Tokens e chaves de API devem ficar fora do navegador. O front-end só deve receber os dados já tratados.
